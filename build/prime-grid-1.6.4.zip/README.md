# Prime Grid

![Prime Grid logo](prime-grid.png)

## A prime grid for your projects!
### Customizable, lightweight and flexible grid library.

[**Documentation**](http://nmihalyov.tk/prime-grid/)

Clone: 
**`git clone https://github.com/nmihalyov/prime-grid.git`**

Install via NPM:
**`npm i prime-grid`**

Install via Yarn:
**`yarn add prime-grid`**

## Обратная связь
Почта: [nikita.mihalyov@gmail.com](mailto:nikita.mihalyov@gmail.com)

Telegram: [@nmihalyov](http://t.me/nmihalyov)

ВКонтакте: [vk.com](https://vk.com/nmihalyov)

Мой сайт: [nmihalyov.tk](http://nmihalyov.tk)

[Написать issue](https://github.com/nmihalyov/prime-grid/issues/new)